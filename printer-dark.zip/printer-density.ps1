# Mohsin Garments — Epson TM-T88V print density (gehra/halka) set karna
# Epson ESC/POS: GS ( E fn=1 (user setting mode) -> fn=5 a=5 (print density) -> fn=2 (save + restart)
# Setting printer ki memory mein save hoti hai (band karne par bhi rehti hai).
param([int]$Level = 120)

$map = @{ 100 = 100; 105 = 1; 110 = 2; 115 = 3; 120 = 4; 125 = 5; 130 = 6 }   # 100 = factory default
if (-not $map.ContainsKey($Level)) { Write-Host "Level sirf 100,105,110,115,120,125,130 ho sakta hai"; Read-Host "Enter dabayen"; exit 1 }
$val = $map[$Level]

Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public class RawPrint {
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public class DOCINFO { public string pDocName; public string pOutputFile; public string pDataType; }
  [DllImport("winspool.drv", CharSet=CharSet.Unicode, SetLastError=true)] public static extern bool OpenPrinter(string n, out IntPtr h, IntPtr d);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", CharSet=CharSet.Unicode, SetLastError=true)] public static extern int StartDocPrinter(IntPtr h, int level, [In] DOCINFO di);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);
  public static string Send(string printer, byte[] data, string doc) {
    IntPtr h;
    if (!OpenPrinter(printer, out h, IntPtr.Zero)) return "OpenPrinter fail " + Marshal.GetLastWin32Error();
    var di = new DOCINFO(); di.pDocName = doc; di.pDataType = "RAW";
    if (StartDocPrinter(h, 1, di) == 0) { ClosePrinter(h); return "StartDoc fail " + Marshal.GetLastWin32Error(); }
    StartPagePrinter(h); int w; bool ok = WritePrinter(h, data, data.Length, out w); EndPagePrinter(h); EndDocPrinter(h); ClosePrinter(h);
    return ok ? "OK" : "Write fail " + Marshal.GetLastWin32Error();
  }
}
"@

# Printer dhoondo (naam mein T88 / TM-T / EPSON)
$all = @(Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name)
$pick = @($all | Where-Object { $_ -match 'T88' })
if ($pick.Count -eq 0) { $pick = @($all | Where-Object { $_ -match 'TM-T|EPSON' }) }
if ($pick.Count -eq 1) { $printer = $pick[0] }
else {
  Write-Host "Printers:"; for ($i = 0; $i -lt $all.Count; $i++) { Write-Host "  $($i+1). $($all[$i])" }
  $n = Read-Host "Epson printer ka number likhein"
  $printer = $all[[int]$n - 1]
}
Write-Host "Printer: $printer  ->  density $Level%"

$lo = [byte]($val -band 0xFF); $hi = [byte](($val -shr 8) -band 0xFF)
[byte[]]$cmd = 0x1D,0x28,0x45,0x03,0x00,0x01,0x49,0x4E  # user setting mode shuru ("IN")
$cmd += 0x1D,0x28,0x45,0x04,0x00,0x05,0x05,$lo,$hi     # a=5 print density
$cmd += 0x1D,0x28,0x45,0x04,0x00,0x02,0x4F,0x55,0x54   # save + khatam ("OUT") — printer restart hota hai
$r = [RawPrint]::Send($printer, $cmd, "MG density")
Write-Host "Setting bheji: $r"
if ($r -ne "OK") { Write-Host "Nahi hua. Printer ON hai aur USB laga hai? Screenshot bhej dein."; Read-Host "Enter dabayen"; exit 1 }

Write-Host "Printer restart ho raha hai, 6 second..."; Start-Sleep -Seconds 6
$txt = [System.Text.Encoding]::ASCII.GetBytes("MOHSIN GARMENTS`nPrint density: $Level %`n1234567890 ABCDEFGH`n`n`n`n")
[byte[]]$test = 0x1B,0x40, 0x1B,0x61,0x01, 0x1B,0x45,0x01
$test += $txt
$test += 0x1D,0x56,0x42,0x00                             # feed + cut
$r2 = [RawPrint]::Send($printer, $test, "MG density test")
Write-Host "Test parchi: $r2"
Write-Host ""; Write-Host "Ho gaya. Ab app se Test print karke dekhein."
Read-Host "Band karne ke liye Enter dabayen"
