@echo off
title Mohsin Garments - Printer density 100%
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0printer-density.ps1" -Level 100
