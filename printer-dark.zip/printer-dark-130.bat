@echo off
title Mohsin Garments - Printer density 130%
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0printer-density.ps1" -Level 130
